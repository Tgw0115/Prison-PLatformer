﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Unity Attributes!
// We've seen a few already, but a few other useful ones:
//      HideInInspector, SerializeField, AddComponentMenu, DisallowMultipleComponent, Header, 
//      ToolTip, Space, TextArea
// See attributes doc: https://docs.unity3d.com/Manual/Attributes.html
// See sidebar for all attributes: https://docs.unity3d.com/ScriptReference/AddComponentMenu.html

// You can include multiple attributes on one line, like this:
//  [DisallowMultipleComponent, RequireComponent(typeof(Rigidbody2D))]
// But it is easier to read if you place each on a separate line:
[DisallowMultipleComponent]
[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(BoxCollider2D))]
public class PlayerMovement : MonoBehaviour
{
    [Header("Ground Movement")]
    [Tooltip("Movement speed in tiles per second")]
    [Range(0f, 20f)]
    [SerializeField] 
    private float speed = 5f;

    [Tooltip("Vertical force applied when jumping")]
    [Range(0f, 20f)]
    [SerializeField] 
    private float jumpForce = 3f;

    private Rigidbody2D playerRigidbody;
    private float horizontalInput;
    private bool isFacingRight = true;

    void Start()
    {
        playerRigidbody = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Check for horizontal input. Configure the gravity and sensitivity in the input manager to
        // control how quickly the player speeds up and slows down in response to key presses.
        horizontalInput = Input.GetAxis("Horizontal");

        // Move the rigidbody. Note: we don't want to move here using Transform.Translate. Since the
        // player is part of the physics system, we want to direct the movement through the physics system.
        Vector2 currentVelocity = playerRigidbody.velocity;
        currentVelocity.x = horizontalInput * speed;
        playerRigidbody.velocity = currentVelocity;
        
        // Flip the sprite if necessary.
        if ((isFacingRight && horizontalInput < 0) ||
            (!isFacingRight && horizontalInput > 0))
        {
            Flip();
        }
    }

    void Flip()
    {
        isFacingRight = !isFacingRight;
        Vector2 scale = transform.localScale;
        scale.x = isFacingRight ? 1 : -1;
        transform.localScale = scale;
    }
}
